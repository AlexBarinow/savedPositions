package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.db.SavedPositions;
import com.example.myapplication.db.MyDao;
import com.example.myapplication.db.MyDatabase;

import java.util.List;

public class MainActivity extends AppCompatActivity {



    MyDatabase db;
    MyDao dao;
    SavedPositions savedPositions;
     static int position = 1;

    final long ID = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



            db = Room.databaseBuilder(getApplicationContext(), MyDatabase.class, "datassьss")
                    .allowMainThreadQueries().build();
            dao = db.getMyDao();


            savedPositions = new SavedPositions(ID, position);
            try {
                dao.addPosition(savedPositions);
            }
            catch (Exception ex){

            }





       // List<SavedPositions> saved = dao.getPositions();
        //position = saved.get(0).getPosition();

        //savedPositions = new SavedPositions(ID, position);

        //if (!saved.isEmpty())
        //dao.updatePosition(savedPositions);

        show(dao);


    }

    private void show(MyDao dao) {
        String all = "";
        List<SavedPositions> saved = dao.getPositions();
        for (SavedPositions savedPositions1 : saved) {
         all += savedPositions1.getPosition();
        }
        TextView textView = findViewById(R.id.textView);
        textView.setText(all);
    }

    public void makeToast(String string){

        Toast.makeText(this, string, Toast.LENGTH_LONG).show();
    }

    public void add(View view) {

        position++;

        savedPositions=new SavedPositions(ID, position);
        dao.updatePosition(savedPositions);
        show(dao);


    }



    public void del(View view) {
        position =0;


        savedPositions=new SavedPositions(ID, position);
        dao.updatePosition(savedPositions);
        show(dao);
    }
}
