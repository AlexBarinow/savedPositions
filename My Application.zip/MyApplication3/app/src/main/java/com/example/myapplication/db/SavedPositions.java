package com.example.myapplication.db;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity()
public class SavedPositions {

    @PrimaryKey(autoGenerate = true)
    private Long id;

    private int position;

    public SavedPositions(Long id, int position) {
        this.position = position;
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public int getPosition() {
        return position;
    }

}